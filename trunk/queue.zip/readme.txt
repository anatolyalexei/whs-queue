WHS-Queue
License in Creative Commons Attribution-Noncommercial-No Derivative Works 3.0

--Install---------------------------
1.Change values in config.php. Every value have a comment next to it to describe what is it
2.Upload everything to your server.
3.Run install.php and if it is error, check debug infomation and check your config file.
4.Enjoy!