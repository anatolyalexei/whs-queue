<?php
//WHS-Queue 1.0
//en.php
//Translated by: Win(manatsawin [at] gmail [dot] nospamplease [dot] com)
$lang['number'] = "<b>Queue number : </b>"; //Queue number : 5
$lang['headcard'] = "Queue Card"; //Header of Queue card
$lang['title'] = "WHS-Queue"; //Title of All pages
$lang['counter'] = "Counter"; //Counter number
$lang['num'] = "Queue"; //current queue
$lang['new'] = "New Ticket"; //New Ticket
$lang['stop'] = "Stop Update"; //Stop updating in Board
$lang['con'] = "Continue Update"; //Continue using update
$lang['board'] = "Board"; //Board that showing what number on what counter
$lang['task'] = "This machine is for..."; //Show in homepage
$lang['current'] = "Current Queue: "; //Show in counter page
$lang['nextqueue'] = "Next Queue"; //Show in counter page
$lang['noqueue'] = "No Queue"; //When no customer
$lang['go'] = "Go"; //Input a counter number
$lang['counum'] = "Counter number: "; //Prompt to input a counter number
$lang['nocounter']="No such counter. <a href=counter.php>Back</a> or "; //No counter and a link back to counter.php and " or " word
$lang['addcounter'] ="add new counter"; //add new counter to the database